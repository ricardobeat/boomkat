// Exercise own data reads on function objects, including layout and descriptor
// changes after the site has warmed. Run with and without JIT.
function Maker() {}
Maker.marker = 21;
function functionNamedRead(f) { return f.marker; }
for (var i = 0; i < 5000; i++) {
    if (functionNamedRead(Maker) !== 21) throw Error('warm static read');
}
Maker.marker = 22;
for (var j = 0; j < 10000; j++) { var churn = { item: j }; }
if (functionNamedRead(Maker) !== 22) throw Error('value change');
Maker.extra = 1;
if (functionNamedRead(Maker) !== 22) throw Error('layout growth');
function other() {}
other.marker = 23;
if (functionNamedRead(other) !== 23) throw Error('other function');
var calls = 0;
Object.defineProperty(Maker, 'marker', { configurable: true, get: function () { calls++; return 24; } });
if (functionNamedRead(Maker) !== 24 || calls !== 1) throw Error('accessor');
delete Maker.marker;
Object.setPrototypeOf(Maker, { marker: 25 });
if (functionNamedRead(Maker) !== 25) throw Error('inherited fallback');
var ordinary = { marker: 26 };
if (functionNamedRead(ordinary) !== 26) throw Error('ordinary fallback');
function reserved(f) { return f.name + ':' + f.length; }
if (reserved(other) !== 'other:0') throw Error('lazy function fields');
print('jit_function_named_read: PASS');
